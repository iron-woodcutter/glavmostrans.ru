Internationalization (i18n)
---------------------------
Missing a language? Just copy `en.json` and translate it.

Please use [List of ISO 639-1 codes](http://en.wikipedia.org/wiki/List_of_ISO_639-1_codes) (see column 639-1 of Partial ISO 639 table) for set language file name.

Example: `[language code].json`.

**Note:** your language file will be removed after the update plugin. If you want to share your language file and it was added in the next release please [contact support](http://www.getmotopress.com/contacts/).